backend Dev (the casino owner)

Server.js (simular to Sav auth)

- keep track of the wins and loses | Calc should  be in here

Passport.Js -

 Only the casino can see the wins and loses

need routes.js

need a monogo db -

storing the data for the manager to see the net profit
Want to see the NET Profit and NET Loss for the manager to see

and post on herouko

*hiding the login information for the owner

For the login making a small login in the bottom of the screen(Making  no  button)

** taking information from the client side and storing the winning and loses


Profile page:

One box for total wins

One box for NET Profit

One Box NET Loss

casino login page see's the total number of wins (amount of wins) for the owner and the loss (amount of loss) and the amount of each

User is the casino owner

creating a API that holds the values of the wins and loses to store the information in the DB!



frontend Dev

JavaScript:

using a counter  for he user to be able to see  how much they are winning and lossing

math.random for  pick the winning color from users betting

conditional that checks who is the winners

user able to bet


HTML:

having a section of div of images of chips for the user to click on that has differnt values and it will there betting

user will be able to click on the chips as many times as they want to place there bet

chips amount will be valued

input for the amount of money that is being bet

button for spending



CSS:






p.code
